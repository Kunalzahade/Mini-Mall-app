
Mini Mall - Demo PWA (APK-ready)
--------------------------------
This demo contains a mobile-first shopping UI (Amazon-style) with:
- Splash screen (logo + Welcome + animated icons)
- Slider, categories, product grid
- Multi-language demo support (English default)
- Multi-currency toggle (INR/USD/EUR)
- Login modal (simulated Google/Facebook buttons)
- Cart saved in localStorage
- PWA manifest & service worker (basic)

How to test on Android:
1. Transfer the folder to your phone (or download the ZIP).
2. Open index.html in Chrome to preview.
3. To convert to APK, use Web2App Builder / WebView app on Play Store and point to this project's index.html (local) or host the folder on GitHub Pages / Netlify and use its URL in the builder.

If you want, I can also host this demo (free) and give you a direct URL ready for Web2App Builder.
