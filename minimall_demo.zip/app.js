
// Mini Mall demo JS - products, cart, slider, language & currency toggles, login modal (simulated)
const PRODUCTS = [
  {id:1,title:'Trendy T-Shirt',cat:'Clothes',priceINR:399,priceUSD:5,priceEUR:4,image:'https://images.unsplash.com/photo-1520975698510-2b1a1b8a6b43?q=80&w=800&auto=format&fit=crop'},
  {id:2,title:'Phone Case',cat:'Accessories',priceINR:249,priceUSD:3,priceEUR:2,image:'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?q=80&w=800&auto=format&fit=crop'},
  {id:3,title:'Sunglasses',cat:'Accessories',priceINR:799,priceUSD:10,priceEUR:9,image:'https://images.unsplash.com/photo-1518544881358-1f2f3f6a1e7c?q=80&w=800&auto=format&fit=crop'},
  {id:4,title:'Perfume 30ml',cat:'Beauty',priceINR:299,priceUSD:4,priceEUR:3,image:'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?q=80&w=800&auto=format&fit=crop'},
  {id:5,title:'Running Shoes',cat:'Shoes',priceINR:1599,priceUSD:19,priceEUR:17,image:'https://images.unsplash.com/photo-1519741493584-5d5a0f6f8a2a?q=80&w=800&auto=format&fit=crop'},
  {id:6,title:'Blender',cat:'Kitchen',priceINR:3499,priceUSD:42,priceEUR:39,image:'https://images.unsplash.com/photo-1586201375761-83865001e8e1?q=80&w=800&auto=format&fit=crop'},
  {id:7,title:'Analog Watch',cat:'Watches',priceINR:2499,priceUSD:30,priceEUR:27,image:'https://images.unsplash.com/photo-1519741493584-5d5a0f6f8a2a?q=80&w=800&auto=format&fit=crop'},
  {id:8,title:'Grocery Pack',cat:'Grocery',priceINR:199,priceUSD:2.5,priceEUR:2,image:'https://images.unsplash.com/photo-1503602642458-232111445657?q=80&w=800&auto=format&fit=crop'}
];

function $(s){return document.querySelector(s)}
function $all(s){return Array.from(document.querySelectorAll(s))}

let currency = localStorage.getItem('mm_currency') || 'INR';
let cart = JSON.parse(localStorage.getItem('mm_cart')||'[]');
let lang = localStorage.getItem('mm_lang') || 'en';

document.getElementById('currency').value = currency;
document.getElementById('lang').value = lang;

function formatPrice(p){
  if(currency==='INR') return '₹' + p;
  if(currency==='USD') return '$' + p;
  if(currency==='EUR') return '€' + p;
}

function renderProducts(list=PRODUCTS){
  const out = $('#products');
  out.innerHTML = '';
  list.forEach(p=>{
    const div = document.createElement('div'); div.className='card';
    div.innerHTML = `<img src="${p.image}" alt="${p.title}" /><h4>${p.title}</h4><div class="price">${formatPrice(currency==='INR'?p.priceINR:(currency==='USD'?p.priceUSD:p.priceEUR))}</div><div style="display:flex;gap:8px;margin-top:8px;"><button class="btn add" data-id="${p.id}">Add</button><button class="btn alt view" data-id="${p.id}">View</button></div>`;
    out.appendChild(div);
  });
}

function renderCart(){
  const items = $('#cartItems');
  items.innerHTML='';
  let total=0;
  cart.forEach(it=>{
    const p = PRODUCTS.find(x=>x.id===it.id);
    const price = currency==='INR'?p.priceINR:(currency==='USD'?p.priceUSD:p.priceEUR);
    total += price * it.qty;
    const el = document.createElement('div');
    el.innerHTML = `<div style="display:flex;justify-content:space-between;margin-bottom:6px;"><div>${p.title} x ${it.qty}</div><div>${formatPrice(price*it.qty)}</div></div>`;
    items.appendChild(el);
  });
  $('#total').textContent = total;
  $('#cartBtn').textContent = `Cart (${cart.length})`;
}

function addToCart(id){
  const found = cart.find(c=>c.id===id);
  if(found) found.qty++;
  else cart.push({id,qty:1});
  localStorage.setItem('mm_cart',JSON.stringify(cart));
  renderCart();
}

document.addEventListener('click', e=>{
  if(e.target.matches('.add')) addToCart(Number(e.target.dataset.id));
  if(e.target.matches('#cartBtn')) { $('#cart').style.display='block'; }
  if(e.target.matches('#checkout')) { alert('Checkout simulated — integrate payments to go live'); }
  if(e.target.matches('#loginBtn')) { $('#loginModal').style.display='flex'; }
  if(e.target.matches('#closeLogin')) { $('#loginModal').style.display='none'; }
  if(e.target.matches('.cat')) {
    const cat = e.target.textContent;
    renderProducts(PRODUCTS.filter(p=>p.cat===cat));
  }
});

$('#currency').addEventListener('change', e=>{
  currency = e.target.value; localStorage.setItem('mm_currency',currency); renderProducts(); renderCart();
});
$('#lang').addEventListener('change', e=>{
  lang = e.target.value; localStorage.setItem('mm_lang',lang); applyLang();
});

function applyLang(){
  // simple UI translations for demo labels
  const map = {
    en:{search:'Search for products, brands and more', login:'Login', cart:'Cart', welcome:'Welcome to Mini Mall', checkout:'Checkout'},
    hi:{search:'उत्पाद खोजें', login:'लॉगिन', cart:'कार्ट', welcome:'मिनी मॉल में आपका स्वागत है', checkout:'चेकआउट'},
    mr:{search:'उत्पादन शोधा', login:'लॉगिन', cart:'कार्ट', welcome:'Mini Mall मध्ये तुमचे स्वागत आहे', checkout:'चेकआउट'},
    ta:{search:'உதயங்கள் தேடவும்', login:'உள்நுழை', cart:'கர்ட்', welcome:'Mini Mall உங்களுக்கு வரவேற்பு', checkout:'காசோலை'}
  };
  const t = map[lang] || map.en;
  $('#search').placeholder = t.search;
  $('#loginBtn').textContent = t.login;
  $('#cartBtn').textContent = t.cart + ' (' + cart.length + ')';
  document.querySelector('.splash-card h1').textContent = t.welcome;
  $('#checkout').textContent = t.checkout;
}

function startSlider(){
  const slides = document.querySelectorAll('.slider .slide');
  let i=0;
  setInterval(()=>{
    slides.forEach((s,idx)=> s.style.display = (idx===i?'block':'none'));
    i = (i+1)%slides.length;
  },3500);
}

// splash hide after 2.5s
setTimeout(()=>{
  document.getElementById('splash').style.display='none';
  startSlider();
},2500);

renderProducts();
renderCart();
applyLang();
